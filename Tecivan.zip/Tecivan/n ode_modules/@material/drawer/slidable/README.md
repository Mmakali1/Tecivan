# Slideable Drawer

The MDC Slideable Drawer is the subclass for drawers that slide: aka Persistent and Temporary drawers.
It maintains the JavaScript logic for handling touch and transition events. This is not a public API.
It only meant to keep Persistent and Temporary drawers's logic in sync.